package com.example.harjty1;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.ImageButton;

public class CalendarFragment extends Fragment {
    private String date =null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        return inflater.inflate(R.layout.fragment_calendar,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState){
        ImageButton closeButton =view.findViewById(R.id.imagebutton2);

        CalendarView cal2=view.findViewById(R.id.calendarView);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentv=new Intent(getActivity().getBaseContext(),Activity2.class);
                intentv.putExtra("date",date);
                startActivity(intentv);
            }
        });

        cal2.setOnDateChangeListener(new CalendarView.OnDateChangeListener(){
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int i, int ii, int i2){
                date=i2+","+ii+","+i;
            }
        });
    }
}
