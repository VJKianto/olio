package com.example.harjty1;

import android.support.annotation.NonNull;
import android.view.Menu;

import java.util.ArrayList;

public class Restaurant {
    private ArrayList<Menu> menu=new ArrayList<>();
    private String name;


    public Restaurant(String n){name=n;}
    public void addToMenu(Menu m){menu.add(m);}

    @NonNull
    @Override
    public String toString(){return name;}
}
