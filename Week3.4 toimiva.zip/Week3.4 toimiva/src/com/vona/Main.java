import java.util.Scanner;
import java.util.ArrayList;
public class Mainclass {
    public static void main(String[] args) {
        int a=0;
        BottleDispenser kone = new BottleDispenser();
        while (a==0){
            Scanner scanner1 = new Scanner(System.in);
            System.out.println("");
            System.out.println("*** BOTTLE DISPENSER ***");
            System.out.println("1) Add money to the machine");
            System.out.println("2) Buy a bottle");
            System.out.println("3) Take money out");
            System.out.println("4) List bottles in the dispenser");
            System.out.println("0) End");
            System.out.print("Your choice: ");
            int choice = scanner1.nextInt();
            if (choice==0){
                break;
            }
            else if (choice==1){
                kone.addMoney();
            }
            else if (choice==2){
                kone.buyBottle();
            }
            else if (choice==3){
                kone.returnMoney();
            }
            else if(choice==4){
                kone.listBottles1();
            }

        }






    }
}