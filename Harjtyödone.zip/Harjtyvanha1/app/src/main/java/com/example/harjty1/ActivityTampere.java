package com.example.harjty1;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
//same as MainActivity but for a different university. Since the activities are nearly identical, Mainactivity includes all the commenting.
public class ActivityTampere extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private Button Menu1;
    private Button Menu2;
    private Button Menu3;
    private Button Menu4;
    private Button feedback1;
    private Button feedback2;
    private Button feedback3;
    private Button feedback4;
    private Button UserMenu;
    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tampere);

//each of these buttons takes the user to the menu/feedback portion of the app
        Menu1 = (Button) findViewById(R.id.button2);
        Menu1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2();
            }
        });
        Menu2 = (Button) findViewById(R.id.button5);
        Menu2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity22();
            }
        });
        Menu3 = (Button) findViewById(R.id.button7);
        Menu3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity23();
            }
        });


        //each of these buttons takes the user to see other people's reviews
        feedback1 = (Button) findViewById(R.id.button4);
        feedback1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity3();
            }
        });
        feedback2 = (Button) findViewById(R.id.button8);
        feedback2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity32();
            }
        });
        feedback3 = (Button) findViewById(R.id.button6);
        feedback3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity33();
            }
        });


        UserMenu = (Button) findViewById(R.id.buttonm);
        UserMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity4();
            }
        });

        Spinner spinner = findViewById(R.id.spinner1);   //creating a spinner for the menu items
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.yliopistot, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        Fragment fragment;
        switch (position) {
            case 0:

                break;

            case 1:
                openActivityAalto();
                break;
            case 2:
                openActivityTampere();
                break;
            case 3:
                openActivityMain();
                break;

        }
        //Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show(); //turha ominaisuus
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void openActivity2() {
        Intent intent = new Intent(this, Activity2Tre.class);
        startActivity(intent); //takes the user to the menu/feedback portion of the app
    }
    public void openActivity22() {
        Intent intent = new Intent(this, Activity22Tre.class);
        startActivity(intent); //takes the user to the menu/feedback portion of the app
    }
    public void openActivity23() {
        Intent intent = new Intent(this, Activity23Tre.class);
        startActivity(intent); //takes the user to the menu/feedback portion of the app
    }


    public void openActivity3() {
        Intent intent = new Intent(this, Activity3Tre.class);
        startActivity(intent); //takes the user to see other people's reviews
    }
    public void openActivity32() {
        Intent intent = new Intent(this, Activity32Tre.class);
        startActivity(intent); //takes the user to see other people's reviews
    }
    public void openActivity33() {
        Intent intent = new Intent(this, Activity33Tre.class);
        startActivity(intent); //takes the user to see other people's reviews
    }

    public void openActivity4() {
        Intent intent = new Intent(this, Activity4.class);
        startActivity(intent); //takes the user to the menu
    }

    public void openActivityAalto() {
        Intent intent = new Intent(this, ActivityAalto.class);
        startActivity(intent); //takes the user to the menu
    }

    public void openActivityTampere() {
        Intent intent = new Intent(this, ActivityTampere.class);
        startActivity(intent); //takes the user to the menu
    }

    public void openActivityMain() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent); //takes the user to the menu
    }




}



