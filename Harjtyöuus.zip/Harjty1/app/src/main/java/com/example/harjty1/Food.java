package com.example.harjty1;

import android.support.annotation.NonNull;

public class Food {
    public String name="default";
    public Food(String n){name=n;}
    @NonNull
    @Override
    public String toString(){return name;}
}
