package com.example.app4;
//Visa Kianto teht 7.3!!!
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {
    static TextView text;
    static EditText mEdit;
    Button   mButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //this.testFunction();
        mButton = (Button) findViewById(R.id.button);
        mEdit = (EditText) findViewById(R.id.editText);
        text = (TextView) findViewById(R.id.textView);

        mButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                String strName;
                strName =mEdit.getText().toString();
                text.setText(strName);
                System.out.println(strName);
            }
        });
    }
    public static void okClick(View view){
        String strName;
        strName =mEdit.getText().toString();
        text.setText(strName);



    }
}





