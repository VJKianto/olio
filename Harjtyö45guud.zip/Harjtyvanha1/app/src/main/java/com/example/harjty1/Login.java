package com.example.harjty1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;


public class Login extends AppCompatActivity {

    private EditText Name;
    private EditText Password;
    private TextView Info;
    private TextView Info2;
    private Button Login;
    private Button Register;
    private EditText Code;
    private Button Submit;
    private TextView Namee;
    private Button UserLogin;
    Random random = new Random();
    int randomNumber = random.nextInt(999999-111111) + 111111;
    String num = Integer.toString(randomNumber);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AccountInfo accinf=new AccountInfo();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);


        Name = (EditText)findViewById(R.id.etName);
        Namee = (TextView) findViewById(R.id.namee);
        Password = (EditText)findViewById(R.id.etPassword);
        Info = (TextView)findViewById(R.id.tvInfo);
        Login = (Button)findViewById(R.id.btnLogin);
        Code=(EditText)findViewById(R.id.Code);
        Info2 = (TextView)findViewById(R.id.hint);
        Register=(Button)findViewById(R.id.registerb);
        UserLogin=(Button)findViewById(R.id.userlogin);


        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPreflogin", 0); // 0 - for private mode
                SharedPreferences.Editor editor = pref.edit();
                String nimi = Name.getText().toString();
                String passu = Password.getText().toString();
                editor.putString("nameregister", nimi);// Storing the name
                editor.putString("password", passu);// Storing the password
                editor.apply();

            }
        });

        UserLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPreflogin", 0); // 0 - for private mode
                String namereg=pref.getString("nameregister",null);
                String passreg=pref.getString("password",null);
                String namen = Name.getText().toString();
                String passen = Password.getText().toString();
                if (namen.equals(namereg)&&passen.equals(passreg)) {
                    System.out.println("Congrats you are in!");
                }
                else {
                    System.out.println("Try again!");
                }
                }


        });


        Info.setText("The password must follow the qualities of a good password");
        Namee.setText((CharSequence) accinf.getName());

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(Name.getText().toString(), Password.getText().toString(),Code.getText().toString());
            }
        });

    }

    private void validate(String userName, String userPassword,String Code){
        if((userName.equals("Admin")) && (userPassword.equals("Admin"))){ //Admin login 1
            Intent intent = new Intent(Login.this, Login2.class);
            startActivity(intent);
        }
        else if(userName.equals("Admin2")) {  //Admin2 login has to have the qualities of a good password
            int min = 12;
            int max = 24;
            int digit = 0;
            int special = 0;
            int upCount = 0;
            int loCount = 0;
            String password;



            password = userPassword;
            if (password.length() >= min && password.length() <= max) {
                for (int i = 0; i < password.length(); i++) {
                    char c = password.charAt(i);
                    if (Character.isUpperCase(c)) {
                        upCount++;
                    }
                    if (Character.isLowerCase(c)) {
                        loCount++;
                    }
                    if (Character.isDigit(c)) {
                        digit++;
                    }
                    if (c >= 33 && c <= 46 || c == 64) {
                        special++;
                    }
                }
                if (special >= 1 && loCount >= 1 && upCount >= 1 && digit >= 1) {
                    Info.setText(num);
                    Info2.setText("Press login after typing in the correct code");


                    if (Code.equals(num)) {
                        Intent intent = new Intent(Login.this, Login2.class);
                        startActivity(intent);
                        System.out.println("moi");
                    }

                } else {
                    Info.setText("Try again");



                }

            }
        }
        else{


            Info.setText("Try again");


            }

    }

}
