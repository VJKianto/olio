package com.example.week103;
//week 10.4!!
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    WebView web;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        web = findViewById(R.id.webView);
        web.setWebViewClient(new WebViewClient());
        web.getSettings().setDomStorageEnabled(true);
        web.loadUrl("http://www.google.fi");


        Button button = (Button) findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                web.reload();

            }
        });
    }

    public void executeJavascript(View v) {
        web.evaluateJavascript("javascript:shoutOut()", null);

    }

    public void onBackPressed(View v) {
        if (web.canGoBack())
            web.goBack();
        else
            super.onBackPressed();
    }
    public void onNextPressed(View v) {
        if (web.canGoForward())
            web.goForward();
        else
            super.onBackPressed();
    }
}

//package com.example.week103;
//
//import androidx.annotation.RequiresApi;
//import androidx.appcompat.app.AppCompatActivity;
//
//import android.content.DialogInterface;
//import android.os.Build;
//import android.os.Bundle;
//import android.view.View;
//import android.webkit.WebView;
//import android.webkit.WebViewClient;
//import android.widget.Button;
//
//
//
//
//public class MainActivity extends AppCompatActivity {
//    WebView web;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//        web= findViewById(R.id.webView);
//        web.setWebViewClient(new WebViewClient());
//        web.getSettings().setJavaScriptEnabled(true);
//        web.loadUrl("file:///android_asset/Index.html");
//
//        Button button = (Button) findViewById(R.id.button);
//
//        button.setOnClickListener(new View.OnClickListener() {
//
//            public void onClick(View v) {
//
//                web.reload();
//
//            }
//        });
//    }
//    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
//    public void executeJavascript(View v){
//        web.evaluateJavascript("javascript:shoutOut()",null);
//    }
//}