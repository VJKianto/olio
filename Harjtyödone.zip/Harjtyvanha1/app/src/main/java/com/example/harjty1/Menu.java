package com.example.harjty1;

import java.util.ArrayList;

public class Menu {
    public String date;
    private ArrayList<Food> foods=new ArrayList<> (  ); //new arraylist
    public Menu (String d){date=d;}
    public void addFood(String name){foods.add(new Food(name));} //adds food

}
