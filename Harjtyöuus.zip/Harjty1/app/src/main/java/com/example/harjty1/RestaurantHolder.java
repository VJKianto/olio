package com.example.harjty1;

import android.content.Context;
import android.view.Menu;
import android.view.MenuItem;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class RestaurantHolder {
    private static RestaurantHolder rh=new RestaurantHolder();
    private ArrayList<Restaurant> restaurants=new ArrayList<>();

    private RestaurantHolder(){

    }
    public static RestaurantHolder getInstance(){return rh;}

    public void parseXML(Context context){
        try {
            InputStream ins=context.getAssets().open("menus.xml");
            DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc=db.parse(ins);

            doc.getDocumentElement().normalize();

            NodeList list=doc.getDocumentElement().getElementsByTagName("restaurant");
            System.out.println(String.valueOf(list.getLength()));

            for (int i=0;i<list.getLength();i++){
                Node node =list.item(i);

                if(node.getNodeType()== Node.ELEMENT_NODE){
                    Element element =(Element) node;

                    String name = element.getElementsByTagName("name").item(0).getTextContent();
                    NodeList dates =element.getElementsByTagName("date");
                    Restaurant restaurant=new Restaurant(name);

                    for (int j=0;j<dates.getLength();j++){
                        Node n=dates.item(j);
                        System.out.println(n.getTextContent());
                        Menu menu = new Menu(n.getTextContent());


                        NodeList foods =n.getChildNodes();
                        for (int k=0;k<foods.getLength();k++) {
                            menu.add(foods.item(k).getTextContent());
                        }
                        restaurant.addToMenu(menu);
                        }
                    restaurants.add(restaurant);
                    }
                }

            } catch (ParserConfigurationException e){
            e.printStackTrace();
        }catch (SAXException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public ArrayList<Restaurant> getRestaurants() {
        return restaurants;
    }
}
