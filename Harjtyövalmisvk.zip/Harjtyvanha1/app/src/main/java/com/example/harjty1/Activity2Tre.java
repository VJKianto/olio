package com.example.harjty1;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;

import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.ArrayList;

import static java.util.Calendar.*;
import android.content.SharedPreferences;
import android.widget.TextView;
import android.content.Context;
//SAME AS ACTIVITY2, BUT FOR A DIFFERENT UNIVERSITY. ACTIVITY2 CONTAINS ALL THE NECESSARY COMMENTING.

public class Activity2Tre extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private static final String MY_PREFS_NAME = null;
    SharedPreferences sharedpreferences;
    SharedPreferences sharedpreferences2;
    TextView feedbackki;
    TextView number;

    String ruoka=null;


    Context context;

    final GregorianCalendar cal = new GregorianCalendar();



    int i = cal.get(DAY_OF_WEEK);
    int week = cal.get(WEEK_OF_YEAR);
    Button menubutton;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2tre);
        final Spinner mySpinner = (Spinner) findViewById(R.id.spinner3);


        //week of year esim viikot 16,18,20,22,24 on monday1 jne ja viikot 17,19,21,23 on monday 2

        Button nextday = findViewById(R.id.nextday);
        Button send = findViewById(R.id.send);
        Button menubutton = findViewById(R.id.buttonm);




        Intent dateintent = getIntent();
        String date = dateintent.getStringExtra("date");//Gets the date selected by the calendar activity
        System.out.println(date);
        Intent dayintent = getIntent();
        String day2 = dayintent.getStringExtra("day");//Gets the day selected by the calendar activity
        System.out.println(day2);
        Intent dagenintent = getIntent();
        Integer day=dagenintent.getIntExtra("dagen",0);//Gets the date selected by the calendar activity

        menubutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenu();
            }
        });


        int i = cal.get(DAY_OF_WEEK);

        nextday.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // Code here executes on main thread after user presses button
                /*i++;
                System.out.println(i);
                datesetter();*/
               /*Intent intentcal=new Intent(this,CalendarActivity.class);
               startActivity(intentcal);*/
                openCalendar();

            }
        });

        //the menu rotates every week based on if it's an odd or even numbered week
        // set day of the week +1 kun painat next day button?


        //EditText et = (EditText) findViewById(R.id.feedback); //feedback
        //String fb = et.getText().toString(); //feedback as a string
        //System.out.println(fb);


        /*Spinner spinner4 = findViewById(R.id.spinner4);   //creating a spinner for the restaurants
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,
                R.array.ravintolat, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner4.setAdapter(adapter2);
        spinner4.setOnItemSelectedListener(this);*/


        feedbackki = (TextView) findViewById(R.id.feedback);
        number = (TextView) findViewById(R.id.numberr);

        /*sharedpreferences = getSharedPreferences(mypreference,
                Context.MODE_PRIVATE);
        if (sharedpreferences.contains(Name)) {
            feedbackki.setText(sharedpreferences.getString(Name, ""));
        }*/





        //feedbackki.setText(sharedpreferences.getString( ));



        //Button mbutton1 = (Button) findViewById(R.id.testibutton);
        ArrayList<Integer> even = new ArrayList<Integer>(99);
        //EditText number=(EditText) findViewById(R.id.numberr);

        // week of the year list, even numbers




        ArrayList<Integer> days1 = new ArrayList<Integer>(99);
        ArrayList<Integer> days2 = new ArrayList<Integer>(99);
        ArrayList<Integer> days3 = new ArrayList<Integer>(99);
        ArrayList<Integer> days4 = new ArrayList<Integer>(99);
        ArrayList<Integer> days5 = new ArrayList<Integer>(99);
        ArrayList<Integer> days6 = new ArrayList<Integer>(99);
        ArrayList<Integer> days7 = new ArrayList<Integer>(99);

        days1.addAll(Arrays.asList(1, 8, 15, 22, 29));
        days2.addAll(Arrays.asList(2, 9, 16, 23, 30));
        days3.addAll(Arrays.asList(3, 10, 17, 24, 31));
        days4.addAll(Arrays.asList(4, 11, 18, 25));
        days5.addAll(Arrays.asList(5, 12, 19, 26));
        days6.addAll(Arrays.asList(6, 13, 20, 27));
        days7.addAll(Arrays.asList(7, 14, 21, 28));
        boolean dayz1 = days1.contains(day);
        boolean dayz2 = days2.contains(day);
        boolean dayz3 = days3.contains(day);
        boolean dayz4 = days4.contains(day);
        boolean dayz5 = days5.contains(day);
        boolean dayz6 = days6.contains(day);
        boolean dayz7 = days7.contains(day);

        ArrayList<Integer> days11 = new ArrayList<Integer>(99);
        ArrayList<Integer> days22 = new ArrayList<Integer>(99);
        ArrayList<Integer> days33 = new ArrayList<Integer>(99);
        ArrayList<Integer> days44 = new ArrayList<Integer>(99);
        ArrayList<Integer> days55 = new ArrayList<Integer>(99);
        ArrayList<Integer> days66 = new ArrayList<Integer>(99);
        ArrayList<Integer> days77 = new ArrayList<Integer>(99);


        days11.addAll(Arrays.asList(8, 22));
        days22.addAll(Arrays.asList(9, 23));
        days33.addAll(Arrays.asList(10, 24));
        days44.addAll(Arrays.asList(11, 25));
        days55.addAll(Arrays.asList(12, 26));
        days66.addAll(Arrays.asList(13, 27));
        days77.addAll(Arrays.asList(14, 28));

        boolean dayz11 = days11.contains(day); //check if contains the date selected by the calendar
        boolean dayz22 = days22.contains(day);
        boolean dayz33 = days33.contains(day);
        boolean dayz44 = days44.contains(day);
        boolean dayz55 = days55.contains(day);
        boolean dayz66 = days66.contains(day);
        boolean dayz77 = days77.contains(day);

        if (dayz1) {//week starts on sunday, hence monday==2

            //mbutton1.setText("Monday");
            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.monday1, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
           /* } else if (i == 2 && even1) {
                mbutton1.setText("Monday");
                Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
                ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                        R.array.monday2, android.R.layout.simple_spinner_item);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(adapter);
                spinner.setOnItemSelectedListener(this);*/
        } else if (dayz2) {
            //mbutton1.setText("Tuesday");
            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.tuesday1, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
            /*} else if (i == 3 && even1) {
                mbutton1.setText("Tuesday");
                Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
                ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                        R.array.tuesday2, android.R.layout.simple_spinner_item);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(adapter);
                spinner.setOnItemSelectedListener(this);*/
        } else if (dayz3) {
            //mbutton1.setText("Wednesday");
            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.wednesday1, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
            /*} else if (i == 4 && even1) {
                mbutton1.setText("Wednesday");
                Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
                ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                        R.array.wednesday2, android.R.layout.simple_spinner_item);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(adapter);
                spinner.setOnItemSelectedListener(this);*/
        } else if (dayz4) {
            //mbutton1.setText("Thursday");
            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.thursday1, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
            /*} else if (i == 5 && even1) {
                mbutton1.setText("Thursday");
                Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
                ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                        R.array.thursday2, android.R.layout.simple_spinner_item);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(adapter);
                spinner.setOnItemSelectedListener(this);*/
        } else if (dayz5) {
            //mbutton1.setText("Friday");
            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.friday1, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
            /*} else if (i == 6 && even1) {
                mbutton1.setText("Friday");
                Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
                ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                        R.array.friday2, android.R.layout.simple_spinner_item);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(adapter);
                spinner.setOnItemSelectedListener(this);*/
        } else if (dayz6) {
            //mbutton1.setText("Saturday");
            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.saturday1, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
            /*} else if (i == 7 && even1) {
                mbutton1.setText("Saturday");
                Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
                ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                        R.array.saturday2, android.R.layout.simple_spinner_item);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(adapter);
                spinner.setOnItemSelectedListener(this);*/
        } else if (dayz7) {
            //mbutton1.setText("Sunday");
            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.sunday1, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
        }
        else if (dayz11) {
            //mbutton1.setText("Tuesday");
            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.monday2, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
            Button save = (Button) findViewById(R.id.save);
        } else if (dayz22) {
            //mbutton1.setText("Tuesday");
            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.tuesday2, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
        } else if (dayz33) {
            //mbutton1.setText("Tuesday");
            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.wednesday2, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
        } else if (dayz44) {
            //mbutton1.setText("Tuesday");
            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.thursday2, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
        } else if (dayz55) {
            //mbutton1.setText("Tuesday");
            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.friday2, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
        } else if (dayz66) {
            //mbutton1.setText("Tuesday");
            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.saturday2, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
        } else if (dayz77) {
            //mbutton1.setText("Tuesday");
            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.sunday2, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
        }
        Button save = (Button) findViewById(R.id.save);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //saving the review
                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPreftre", 0); // 0 - for private mode
                SharedPreferences.Editor editor2 = pref.edit();
                try {
                    String fb = feedbackki.getText().toString();
                    String num = number.getText().toString();
                    editor2.putString("feedbacktre", fb);// Storing string
                    editor2.putString("numbertre", num);

                    String ruoka = mySpinner.getSelectedItem().toString();
                    editor2.putString("foodtre", ruoka);

                    editor2.apply();   //saves the review, but is not sent to the feedback activity
                }
                catch (Exception e) {
                }
            }
        });

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //send the review
                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
                SharedPreferences.Editor editor = pref.edit();
                try {
                    String fb = feedbackki.getText().toString();
                    String num = number.getText().toString();
                    editor.putString("feedbackt", fb);// Storing string
                    editor.putString("numbert", num);
                    //if (ruoka!=null){
                    String ruoka = mySpinner.getSelectedItem().toString();
                    editor.putString("foodt", ruoka);//}  //try catch??

                    editor.apply();  //is sent to the feedback activity
                } catch (Exception e) {
                }
            }
        });



        //Spinner.getSelectedItem()

        //startActivity(rintent);  //unnecessary


    }


            /*} else if (i == 1 && even1) {
                mbutton1.setText("Sunday");
                Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
                ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                        R.array.sunday2, android.R.layout.simple_spinner_item);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(adapter);
                spinner.setOnItemSelectedListener(this);
            }*/




    public void Save() {   //testing
        //View view savessa
        /*String n = feedbackki.getText().toString();
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(Name, n);
        editor.commit();*/


    }

    public void Get(View view) {   //testing
        sharedpreferences.getString("key_name", null); // getting String

    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String ruoka = parent.getItemAtPosition(position).toString();  //doesn't work
        SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
        editor.putString("food",ruoka);
        editor.apply();

        //Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show(); turha ominaisuus
        switch (position) {
            case 0:


                break;

            case 1:

                break;
            case 2:

                break;
            case 3:

                break;

        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }




    public void openCalendar() {
        Intent intent = new Intent(this, CalendarActivity.class);

        intent.putExtra ( "info","4");
        startActivity(intent); //takes the user to the menu/feedback portion of the app
    }

    public void openMenu(){
        Intent intentm = new Intent(this, ActivityTampere.class);
        startActivity(intentm); //takes the user to the main menu portion of the app
    }



    public void sendActivity(){

        /*SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        String ruokaa = prefs.getString("food", ruoka);
        Intent ruokaintent=new Intent(Activity2.this,Activity3.class);
        ruokaintent.putExtra("food",ruokaa);  //Spinner.getSelectedItem()  */    //DOESN'T WORK

        /*RatingBar ratingBarr=findViewById(R.id.ratingBar);
        ratingBarr.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
        @Override
        public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser){
        float num=ratingBar.getRating();   //adds rating to the feedback
        String numm=Float.toString(num);
        Intent rintent=new Intent(Activity2.this,Activity3.class);
        rintent.putExtra("rate",numm);
        startActivity(rintent);}

        });*/
        //String fbs=pref.getString("feedback", null); // getting String

        String numb = number.getText().toString();
        Intent intentnumb= new Intent(Activity2Tre.this, Activity3.class);
        intentnumb.putExtra("number",numb);  //rating and sends it




        String n = feedbackki.getText().toString();
        Intent intent= new Intent(Activity2Tre.this, Activity3.class);
        intent.putExtra("key",n);
        startActivity(intentnumb);    //feedback as a text and sends it
    }




}









