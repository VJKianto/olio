import java.util.ArrayList;

public class BottleDispenser {
    ArrayList<Integer> list1 = new ArrayList<Integer>();

    public int bottles;



    private Bottle[] bottle_array;

    public int money;



    public BottleDispenser() {

        bottles = 6;

        money = 0;





    }

    public void listBottles1(){
        bottle_array = new Bottle[bottles];
        for(int i = 1; i < bottle_array.length; i++) {
            System.out.println(i+". Name: Pepsi Max");
            System.out.println("\tSize: 0.5	Price: 1.8");
        }

    }


    public void addMoney() {

        money += 1;


        System.out.println("Klink! Added more money!");

    }



    public void buyBottle() {
        if (bottles>1 && money>1){
            bottles -=1;
            money-=1;
            Bottle nimi = new Bottle();
            System.out.println("KACHUNK! "+nimi.getName()+ " came out of the dispenser!");
        }
        else{
            System.out.println("Add money first!");
        }

    }



    public void returnMoney() {

        money = 0;

        System.out.println("Klink klink. Money came out!");

    }

}

