package com.example.harjty1;

import android.content.Context;
import android.view.MenuItem;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;



public class RestaurantHolder {
    private static RestaurantHolder rh=new RestaurantHolder();
    private ArrayList<Restaurant> restaurants=new ArrayList<>();

    private RestaurantHolder(){

    }
    public static RestaurantHolder getInstance(){return rh;}

    public void parseXML(Context context){ //parsing xml
        try { //inside try/catch
            InputStream ins=context.getAssets().open("menus.xml"); //open food file
            DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder(); //define db
            Document doc=db.parse(ins); //parse menus document

            doc.getDocumentElement().normalize(); //normalizes text

            NodeList list=doc.getDocumentElement().getElementsByTagName("restaurant"); //get document info by restaurant


            for (int i=0;i<list.getLength();i++){ //run through the list
                Node node =list.item(i); //list item node

                if(node.getNodeType()== Node.ELEMENT_NODE){ //if is an element node
                    Element element =(Element) node; //define element

                    String name = element.getElementsByTagName("name").item(0).getTextContent(); //get element by name
                    NodeList dates =element.getElementsByTagName("date");//get element by date
                    Restaurant restaurant=new Restaurant(name);

                    for (int j=0;j<dates.getLength();j++){ //run through while date not chosen
                        Node n=dates.item(j); //define n

                        Menu menu =new Menu ( n.getTextContent () ); //define menu


                        NodeList foods =n.getChildNodes(); //define foods
                        for (int k=0;k<foods.getLength();k++) { //get the food
                            menu.addFood ( foods.item ( k ).getTextContent ( ) ); //add the menu item
                        }
                        restaurant.addToMenu (menu); //add menu
                    }
                    restaurants.add(restaurant); //add to restaurants
                }
            }

        } catch (ParserConfigurationException e){ //catch different errors
            e.printStackTrace();
        }catch (SAXException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public ArrayList<Restaurant> getRestaurants() {
        return restaurants;
    }
}
