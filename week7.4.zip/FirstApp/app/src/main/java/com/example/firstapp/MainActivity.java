package com.example.firstapp;
//Visa Kianto teht 7.4
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
//week 7.4!!!
public class MainActivity extends AppCompatActivity {
    static TextView text;
    static EditText mEdit;
    Button   mButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //this.testFunction();
        mButton = (Button) findViewById(R.id.button);
        mEdit = (EditText) findViewById(R.id.editText);
        text = (TextView) findViewById(R.id.textView);
        mEdit.addTextChangedListener(textWatcher);
    }

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                text.setText(s);

            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        };
    }






