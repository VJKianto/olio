package com.example.harjty1;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

//ADMIN ACTIVITY

public class Login2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login2);
        Context context = null;
        Button clearb=(Button)findViewById(R.id.buttonclear);
        Button menubutton = findViewById(R.id.buttonmenul2);
        menubutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenul2();
            }
        });

        clearb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //upon pressing the clear data button, all the data stored in the application in the sharedpreferences are cleared.
                SharedPreferences preferences1 =getSharedPreferences("MyPref23",Context.MODE_PRIVATE);
                SharedPreferences.Editor editor1 = preferences1.edit();
                SharedPreferences preferences2 =getSharedPreferences("MyPref",Context.MODE_PRIVATE);
                SharedPreferences.Editor editor2 = preferences2.edit();
                SharedPreferences preferences3 =getSharedPreferences("MyPref22",Context.MODE_PRIVATE);
                SharedPreferences.Editor editor3 = preferences3.edit();
                editor1.clear();
                editor1.apply();
                editor2.clear();
                editor2.apply();
                editor3.clear();
                editor3.apply(); //deletes all stored user data from sharedpreferences
            }
        });



    }
    public void openMenul2(){
        Intent intentm = new Intent(this, MainActivity.class);
        startActivity(intentm); //takes the user to the main menu portion of the app
    }
}
