package com.example.harjty1;

import android.content.Intent;
import android.widget.EditText;

import java.util.Objects;

public class AccountInfo extends Activity4 { //storing the given account values
    Activity4 accinfo=new Activity4();

    public EditText getName(){  //doesn't work with a string even if toString is used
        return accinfo.PName;
    }
    public EditText getEmail(){
        return accinfo.Email;
    }
    public EditText getPnum(){
        return accinfo.PNum;
    }
    public EditText getAddress(){
        return accinfo.Address;
    }

    private Intent intent;
    String infoacc = Objects.requireNonNull(intent).getStringExtra("accountname1"); //get user information
    String infoacc2 = intent.getStringExtra("accemail");
    String infoacc3 = intent.getStringExtra("accpnum");
    String infoacc4 = intent.getStringExtra("accaddress");
    String infoacc5 = intent.getStringExtra("accuni");



}
