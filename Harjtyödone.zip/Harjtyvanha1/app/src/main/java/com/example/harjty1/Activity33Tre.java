package com.example.harjty1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;

//SAME AS ACTIVITY33, BUT FOR A DIFFERENT UNIVERSITY.Since the activities are nearly identical, ACTIVITY3 CONTAINS ALL THE NECESSARY COMMENTING.

public class Activity33Tre extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    TextView review;
    TextView ruoka;
    TextView number;
    public RatingBar ratingBar;
    Button menubutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SharedPreferences sharedPreferences = getSharedPreferences("MyPref23", MODE_PRIVATE);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_33tre);
        review=findViewById(R.id.rating1);
        number=findViewById(R.id.toimi);
        ruoka=findViewById(R.id.ruoka1);
        ratingBar=(RatingBar) findViewById(R.id.ratingBar1);
        //SharedPreferences sharedPreferences = getSharedPreferences("MyPref", MODE_PRIVATE);
        String t=sharedPreferences.getString("feedbackt3",null);
        String n=sharedPreferences.getString("numbert3",null);
        String r=sharedPreferences.getString("foodt3",null);

        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
        SharedPreferences.Editor editor = pref.edit();
        float barRating = ratingBar.getRating();
        editor.putFloat("barRating",barRating );// Storing rating


        //String numget=getIntent().getStringExtra("number");
        number.setText(n);
        review.setText(t);
        ruoka.setText(r);

        Button menubutton = findViewById(R.id.buttonm);
        menubutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenu();
            }
        });


        String ratingget=getIntent().getStringExtra("key");
        //review.setText(ratingget);


    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        //Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show(); turha ominaisuus
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    public void openMenu(){
        Intent intentm = new Intent(this, ActivityTampere.class);
        startActivity(intentm); //takes the user to the main menu portion of the app
    }
}
