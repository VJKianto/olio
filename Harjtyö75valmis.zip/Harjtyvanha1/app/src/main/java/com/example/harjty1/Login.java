package com.example.harjty1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;


public class Login extends AppCompatActivity {

    private EditText Name;
    private EditText Password;
    private TextView Info;
    private TextView Info2;
    private Button Login;
    private Button Register;
    private EditText Code;
    private Button Submit;
    private TextView Namee;
    private Button UserLogin;
    Random random = new Random();
    int randomNumber = random.nextInt(999999-111111) + 111111;//Generates a random number
    String num = Integer.toString(randomNumber);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AccountInfo accinf=new AccountInfo();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);


        Name = (EditText)findViewById(R.id.etName);
        Namee = (TextView) findViewById(R.id.namee);
        Password = (EditText)findViewById(R.id.etPassword);
        Info = (TextView)findViewById(R.id.tvInfo);
        Login = (Button)findViewById(R.id.btnLogin);
        Code=(EditText)findViewById(R.id.Code);
        Info2 = (TextView)findViewById(R.id.hint);
        Register=(Button)findViewById(R.id.registerb);
        UserLogin=(Button)findViewById(R.id.userlogin);

        Button menubuttonl = findViewById(R.id.buttonlmenu);
        menubuttonl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenu();
            }
        });


        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //for register your account
                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPreflogin", 0); // 0 - for private mode
                SharedPreferences.Editor editor = pref.edit();
                String nimi = Name.getText().toString(); //takes the given username
                String passu = Password.getText().toString();//takes the given password
                editor.putString("nameregister", nimi);// Storing the name
                editor.putString("password", passu);// Storing the password
                editor.apply(); //applies the editor changes

            }
        });

        UserLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //for logging in to a registered account
                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPreflogin", 0); // 0 - for private mode
                String namereg=pref.getString("nameregister",null);
                String passreg=pref.getString("password",null);
                String namen = Name.getText().toString();
                String passen = Password.getText().toString();
                if (namen.equals(namereg)&&passen.equals(passreg)) { //if the username and password are in the registered database they can be validated for the requirement of a good password and possibly logged in
                    validate2(namen, passen,Code.getText().toString());
                }
                else {
                    System.out.println("Try again!");
                }
                }


        });


        Info.setText("The password must follow the qualities of a good password");
        Namee.setText((CharSequence) accinf.getName());

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { //for logging in to a admin account
                validate(Name.getText().toString(), Password.getText().toString(),Code.getText().toString()); //validates the password and name and lets the user in if they are correct
            }
        });

    }

    private void validate(String userName, String userPassword,String Code){
        if((userName.equals("Admin")) && (userPassword.equals("Admin"))){ //Admin login 1
            Intent intent = new Intent(Login.this, Login2.class);
            startActivity(intent);
        }
        else if(userName.equals("Admin2")) {  //Admin2 login has to have the qualities of a good password
            int min = 12;
            int max = 24;
            int digit = 0;
            int special = 0;
            int upCount = 0;
            int loCount = 0;
            String password;



            password = userPassword;
            if (password.length() >= min && password.length() <= max) {
                for (int i = 0; i < password.length(); i++) { //checks for the requirements
                    char c = password.charAt(i);
                    if (Character.isUpperCase(c)) {
                        upCount++;
                    }
                    if (Character.isLowerCase(c)) {
                        loCount++;
                    }
                    if (Character.isDigit(c)) {
                        digit++;
                    }
                    if (c >= 33 && c <= 46 || c == 64) {
                        special++;
                    }
                }
                if (special >= 1 && loCount >= 1 && upCount >= 1 && digit >= 1) { //if requirements are passed the user is given a six numbered code
                    Info.setText(num);
                    Info2.setText("Press login after typing in the correct code");


                    if (Code.equals(num)) {
                        Intent intent = new Intent(Login.this, Login2.class); //lets the user to the admin activity if the code is correct
                        startActivity(intent);

                    }

                } else {
                    Info.setText("Try again");



                }

            }
        }
        else{


            Info.setText("Try again");


            }

    }
    private void validate2(String userName, String userPassword,String Code){ //same as validate1, but for user login

        
            int min = 12;
            int max = 24;
            int digit = 0;
            int special = 0;
            int upCount = 0;
            int loCount = 0;
            String password;
            password = userPassword;
            if (password.length() >= min && password.length() <= max) {
                for (int i = 0; i < password.length(); i++) {
                    char c = password.charAt(i);
                    if (Character.isUpperCase(c)) {
                        upCount++;
                    }
                    if (Character.isLowerCase(c)) {
                        loCount++;
                    }
                    if (Character.isDigit(c)) {
                        digit++;
                    }
                    if (c >= 33 && c <= 46 || c == 64) {
                        special++;
                    }
                }
                if (special >= 1 && loCount >= 1 && upCount >= 1 && digit >= 1) {
                    Info.setText(num);
                    Info2.setText("Press login after typing in the correct code");


                    if (Code.equals(num)) {

                        Info.setText("You are now logged in. You can resume browsing by going to the main menu");
                    }

                } else {
                    Info.setText("Try again");



                }

            }

        else{


            Info.setText("Try again");


        }

    }
    public void openMenu(){
        Intent intentm = new Intent(this, MainActivity.class);
        startActivity(intentm); //takes the user to the main menu portion of the app
    }

}


