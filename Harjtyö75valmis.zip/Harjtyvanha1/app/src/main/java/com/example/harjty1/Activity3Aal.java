package com.example.harjty1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Objects;

//SAME AS ACTIVITY3, BUT FOR A DIFFERENT UNIVERSITY. ACTIVITY3 CONTAINS ALL THE NECESSARY COMMENTING.

public class Activity3Aal extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    TextView review;
    TextView ruoka;
    TextView number;
    public RatingBar ratingBar;
    Button menubutton;
    final Intent intent = getIntent();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SharedPreferences sharedPreferences = getSharedPreferences("MyPref", MODE_PRIVATE);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3aal);
        review = findViewById(R.id.rating1);
        number = findViewById(R.id.toimi);
        ruoka = findViewById(R.id.ruoka1);
        ratingBar = (RatingBar) findViewById(R.id.ratingBar1);

        //String info = intent.getStringExtra("info2");

        //SharedPreferences sharedPreferences = getSharedPreferences("MyPref", MODE_PRIVATE);
        String t = sharedPreferences.getString("feedbacka", null);
        String n = sharedPreferences.getString("numbera", null);
        String r = sharedPreferences.getString("fooda", null);
        /*
        String ta = sharedPreferences.getString("feedbackaal", null);
        String na = sharedPreferences.getString("numberaal", null);
        String ra = sharedPreferences.getString("foodaal", null);
        String tt = sharedPreferences.getString("feedbacktre", null);
        String nt = sharedPreferences.getString("numbertre", null);
        String rt = sharedPreferences.getString("foodtre", null);

         */
        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
        SharedPreferences.Editor editor = pref.edit();

        float barRating = ratingBar.getRating();
        editor.putFloat("barRating", barRating);// Storing rating
        number.setText(n);
        review.setText(t);
        ruoka.setText(r);


        /*String numget=getIntent().getStringExtra("number");
        //if (Objects.equals(info, "1")) {
            number.setText(n);
            review.setText(t);
            ruoka.setText(r);
        //} else if (Objects.equals(info, "2")) {
            number.setText(na);
            review.setText(ta);
            ruoka.setText(ra);
        }
     //else {
            number.setText(nt);
            review.setText(tt);
            ruoka.setText(rt);
        }*/


        Button menubutton = findViewById(R.id.buttonm);
        menubutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenu();
            }
        });


        //EditText et = (EditText)findViewById(R.id.feedback); //feedback
        // String fb = et.getText().toString(); //feedback as a string

        String ratingget=getIntent().getStringExtra("key");
        //review.setText(ratingget);

        /*ruoka=findViewById(R.id.ruoka1);
        String ruokaget=getIntent().getStringExtra("food");
        ruoka.setText(ruokaget);*/

        /*rating=findViewById(R.id.ratingr);
        String rget=getIntent().getStringExtra("rate");
        rating.setText(rget);*/








        /*Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.ravintolat, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);*/
    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        //Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show(); turha ominaisuus
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    public void openMenu(){
        Intent intentm = new Intent(this, MainActivity.class);
        startActivity(intentm); //takes the user to the main menu portion of the app
    }
}
