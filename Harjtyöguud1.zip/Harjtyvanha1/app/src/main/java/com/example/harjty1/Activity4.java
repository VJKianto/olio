package com.example.harjty1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;


public class Activity4 extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    public EditText PName;
    public EditText Email;
    public EditText PNum;
    public EditText Address;
    private Button Submit;

    //

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_4);
        Spinner spinner = findViewById(R.id.spinner1);   //creating a spinner for the menu items
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.yliopistot, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
        Button loginbutton=(Button) findViewById(R.id.login);
        loginbutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EditText name=(EditText) findViewById(R.id.name);
                startActivity(new Intent(Activity4.this,Login.class));
            }
        });
        PName = (EditText)findViewById(R.id.name);
        Email = (EditText)findViewById(R.id.email);
        PNum = (EditText)findViewById(R.id.phone);
        Address = (EditText)findViewById(R.id.address);
        Submit = (Button)findViewById(R.id.submit);
        /*Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nam=PName.getText().toString();
            }
        });*/
        if(PName.length() >1){
            PName.getText().toString();
        }


    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();

    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

}
