package com.example.harjty1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.ImageButton;

import com.example.harjty1.Activity2;
import com.example.harjty1.R;

import java.util.Objects;

public class CalendarActivity extends AppCompatActivity {
   @Override
   protected void onCreate(Bundle savedInstanceState){
       super.onCreate ( savedInstanceState );
       setContentView ( R.layout.activity_calendar );
       final Intent intent = getIntent();

       CalendarView calendarView =findViewById ( R.id.calendarView );

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener(){
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int i, int ii, int i2) {

                String info = intent.getStringExtra("info");

                if (Objects.equals(info, "1")) {
                    Intent intent = new Intent(CalendarActivity.this, Activity2.class);
                    String date = i2 + "," + ii + "," + i;
                    intent.putExtra("date", date);
                    String day = Integer.toString(i2);
                    intent.putExtra("day", day);
                    Integer dagen = i2;
                    intent.putExtra("dagen", dagen);


                    startActivity(intent);
                } else if (Objects.equals(info, "2")) {
                    Intent intent = new Intent(CalendarActivity.this, Activity22.class);
                    String date = i2 + "," + ii + "," + i;
                    intent.putExtra("date", date);
                    String day = Integer.toString(i2);
                    intent.putExtra("day", day);
                    Integer dagen = i2;
                    intent.putExtra("dagen", dagen);


                    startActivity(intent);
                } else {
                    Intent intent = new Intent(CalendarActivity.this, Activity23.class);

                    String date = i2 + "," + ii + "," + i;
                    intent.putExtra("date", date);
                    String day = Integer.toString(i2);
                    intent.putExtra("day", day);
                    Integer dagen = i2;
                    intent.putExtra("dagen", dagen);


                    startActivity(intent);
                }
            }

        });
    }
}