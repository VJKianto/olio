package com.example.harjty1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.ImageButton;

import com.example.harjty1.Activity2;
import com.example.harjty1.R;

import java.util.Objects;

//Calendar activity

public class CalendarActivity extends AppCompatActivity {
   @Override
   protected void onCreate(Bundle savedInstanceState){
       super.onCreate ( savedInstanceState );
       setContentView ( R.layout.activity_calendar );
       final Intent intent = getIntent();

       CalendarView calendarView =findViewById ( R.id.calendarView );

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener(){
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int i, int ii, int i2) {

                String info = intent.getStringExtra("info"); //gets the variable that defines which activity 2 was used

                if (Objects.equals(info, "1")) { //takes the user back to the activity where the calendar activity was opened from
                    Intent intent = new Intent(CalendarActivity.this, Activity2.class);
                    String date = i2 + "," + ii + "," + i; //day,month,year
                    intent.putExtra("date", date); //stores date
                    String day = Integer.toString(i2);
                    intent.putExtra("day", day);
                    Integer dagen = i2;
                    intent.putExtra("dagen", dagen);


                    startActivity(intent);
                } else if (Objects.equals(info, "2")) {
                    Intent intent = new Intent(CalendarActivity.this, Activity22.class);
                    String date = i2 + "," + ii + "," + i;
                    intent.putExtra("date", date);
                    String day = Integer.toString(i2);
                    intent.putExtra("day", day);
                    Integer dagen = i2;
                    intent.putExtra("dagen", dagen);


                    startActivity(intent);
                } else if (Objects.equals(info, "3")) {
                    Intent intent = new Intent(CalendarActivity.this, Activity2Aal.class);
                    String date = i2 + "," + ii + "," + i;
                    intent.putExtra("date", date);
                    String day = Integer.toString(i2);
                    intent.putExtra("day", day);
                    Integer dagen = i2;
                    intent.putExtra("dagen", dagen);


                    startActivity(intent);
                } else if (Objects.equals(info, "4")) {
                    Intent intent = new Intent(CalendarActivity.this, Activity2Tre.class);
                    String date = i2 + "," + ii + "," + i;
                    intent.putExtra("date", date);
                    String day = Integer.toString(i2);
                    intent.putExtra("day", day);
                    Integer dagen = i2;
                    intent.putExtra("dagen", dagen);


                    startActivity(intent);
                } else if (Objects.equals(info, "5")) {
                    Intent intent = new Intent(CalendarActivity.this, Activity22Aal.class);
                    String date = i2 + "," + ii + "," + i;
                    intent.putExtra("date", date);
                    String day = Integer.toString(i2);
                    intent.putExtra("day", day);
                    Integer dagen = i2;
                    intent.putExtra("dagen", dagen);


                    startActivity(intent);
                } else if (Objects.equals(info, "6")) {
                    Intent intent = new Intent(CalendarActivity.this, Activity22Tre.class);
                    String date = i2 + "," + ii + "," + i;
                    intent.putExtra("date", date);
                    String day = Integer.toString(i2);
                    intent.putExtra("day", day);
                    Integer dagen = i2;
                    intent.putExtra("dagen", dagen);


                    startActivity(intent);
                } else if (Objects.equals(info, "7")) {
                    Intent intent = new Intent(CalendarActivity.this, Activity23Aal.class);
                    String date = i2 + "," + ii + "," + i;
                    intent.putExtra("date", date);
                    String day = Integer.toString(i2);
                    intent.putExtra("day", day);
                    Integer dagen = i2;
                    intent.putExtra("dagen", dagen);


                    startActivity(intent);
                } else if (Objects.equals(info, "8")) {
                    Intent intent = new Intent(CalendarActivity.this, Activity23Tre.class);
                    String date = i2 + "," + ii + "," + i;
                    intent.putExtra("date", date);
                    String day = Integer.toString(i2);
                    intent.putExtra("day", day);
                    Integer dagen = i2;
                    intent.putExtra("dagen", dagen);


                    startActivity(intent);
                } else if (Objects.equals(info, "9")) {
                    Intent intent = new Intent(CalendarActivity.this, Activity23.class);

                    String date = i2 + "," + ii + "," + i;
                    intent.putExtra("date", date);
                    String day = Integer.toString(i2);
                    intent.putExtra("day", day);
                    Integer dagen = i2;
                    intent.putExtra("dagen", dagen);


                    startActivity(intent);
                }
            }

        });
    }
}