package com.example.harjty1;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;

import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.ArrayList;

import static java.util.Calendar.*;
import android.content.SharedPreferences;
import android.widget.TextView;
import android.content.Context;

//HAS ALL THE COMMENTING DONE. IDENTICAL TO OTHER ACTIVITY 2's, BUT EACH ONE IS FOR A DIFFERENT RESTAURANT.

public class Activity2 extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private static final String MY_PREFS_NAME = null;
    SharedPreferences sharedpreferences;
    SharedPreferences sharedpreferences2;
    TextView feedbackki;
    TextView number;

    String ruoka=null;

    Context context;

    final GregorianCalendar cal = new GregorianCalendar();



    int i = cal.get(DAY_OF_WEEK);
    int week = cal.get(WEEK_OF_YEAR);
    Button menubutton;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        final Spinner mySpinner = (Spinner) findViewById(R.id.spinner3);


        Button nextday = findViewById(R.id.nextday);
        Button send = findViewById(R.id.send);
        Button menubutton = findViewById(R.id.buttonm);

        Intent dateintent = getIntent();
        String date = dateintent.getStringExtra("date"); //Gets the date selected by the calendar activity

        Intent dayintent = getIntent();
        String day2 = dayintent.getStringExtra("day");//Gets the day selected by the calendar activity

        Intent dagenintent = getIntent();
        Integer day = dagenintent.getIntExtra("dagen", 0);//Gets the date selected by the calendar activity

        menubutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenu();//opens the main menu activity
            }
        });


        int i = cal.get(DAY_OF_WEEK);

        nextday.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                openCalendar(); //opens the calendar activity

            }
        });

        feedbackki = (TextView) findViewById(R.id.feedback);
        number = (TextView) findViewById(R.id.numberr);

        ArrayList<Integer> days1 = new ArrayList<Integer>(99); //Creating arraylist
        ArrayList<Integer> days2 = new ArrayList<Integer>(99);
        ArrayList<Integer> days3 = new ArrayList<Integer>(99);
        ArrayList<Integer> days4 = new ArrayList<Integer>(99);
        ArrayList<Integer> days5 = new ArrayList<Integer>(99);
        ArrayList<Integer> days6 = new ArrayList<Integer>(99);
        ArrayList<Integer> days7 = new ArrayList<Integer>(99);
        ArrayList<Integer> days11 = new ArrayList<Integer>(99);
        ArrayList<Integer> days22 = new ArrayList<Integer>(99);
        ArrayList<Integer> days33 = new ArrayList<Integer>(99);
        ArrayList<Integer> days44 = new ArrayList<Integer>(99);
        ArrayList<Integer> days55 = new ArrayList<Integer>(99);
        ArrayList<Integer> days66 = new ArrayList<Integer>(99);
        ArrayList<Integer> days77 = new ArrayList<Integer>(99);


        days11.addAll(Arrays.asList(8, 22)); //add dates to the arraylist
        days22.addAll(Arrays.asList(9, 23));
        days33.addAll(Arrays.asList(10, 24));
        days44.addAll(Arrays.asList(11, 25));
        days55.addAll(Arrays.asList(12, 26));
        days66.addAll(Arrays.asList(13, 27));
        days77.addAll(Arrays.asList(14, 28));

        boolean dayz11 = days11.contains(day); //check if contains the date selected by the calendar
        boolean dayz22 = days22.contains(day);
        boolean dayz33 = days33.contains(day);
        boolean dayz44 = days44.contains(day);
        boolean dayz55 = days55.contains(day);
        boolean dayz66 = days66.contains(day);
        boolean dayz77 = days77.contains(day);

        days1.addAll(Arrays.asList(1, 15, 29));//add dates to the arraylist
        days2.addAll(Arrays.asList(2, 16, 30));
        days3.addAll(Arrays.asList(3, 17, 31));
        days4.addAll(Arrays.asList(4, 18));
        days5.addAll(Arrays.asList(5, 19));
        days6.addAll(Arrays.asList(6, 20));
        days7.addAll(Arrays.asList(7, 21));

        boolean dayz1 = days1.contains(day);//check if contains the date selected by the calendar
        boolean dayz2 = days2.contains(day);
        boolean dayz3 = days3.contains(day);
        boolean dayz4 = days4.contains(day);
        boolean dayz5 = days5.contains(day);
        boolean dayz6 = days6.contains(day);
        boolean dayz7 = days7.contains(day);

        if (dayz1) { //based on the date selected gives the user the day's menu


            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.monday1, android.R.layout.simple_spinner_item); //food menu
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);

        } else if (dayz2) {

            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.tuesday1, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);

        } else if (dayz3) {

            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.wednesday1, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);

        } else if (dayz4) {

            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.thursday1, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);

        } else if (dayz5) {

            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.friday1, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);

        } else if (dayz6) {

            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.saturday1, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);

        } else if (dayz7) {

            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.sunday1, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);

        } else if (dayz11) {

            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.monday2, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
            Button save = (Button) findViewById(R.id.save);
        } else if (dayz22) {

            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.tuesday2, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
        } else if (dayz33) {

            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.wednesday2, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
        } else if (dayz44) {

            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.thursday2, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
        } else if (dayz55) {

            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.friday2, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
        } else if (dayz66) {

            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.saturday2, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
        } else if (dayz77) {

            Spinner spinner = findViewById(R.id.spinner3);   //creating a spinner for the menu items
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.sunday2, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);
        }

        Button save = (Button) findViewById(R.id.save);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //saving the review
                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
                SharedPreferences.Editor editor2 = pref.edit();
                try {
                    String fb = feedbackki.getText().toString();//the written review
                    String num = number.getText().toString();//the rating given
                    editor2.putString("feedback", fb);// Storing string
                    editor2.putString("number", num);// Storing string

                    String ruoka = mySpinner.getSelectedItem().toString(); //get the food
                    editor2.putString("food", ruoka);

                    editor2.apply();   //saves the review, but is not sent to the feedback activity
                }
                catch (Exception e) { //catches errors
                }
            }
        });

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //send the review
                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
                SharedPreferences.Editor editor = pref.edit();
                Intent intent = new Intent(Activity2.this, Activity3.class);

                intent.putExtra ( "info2","1");
                try {
                    String fb = feedbackki.getText().toString(); //the written review
                    String num = number.getText().toString(); //the rating given
                    editor.putString("feedback", fb);// Storing string
                    editor.putString("number", num);

                    String ruoka = mySpinner.getSelectedItem().toString();
                    editor.putString("food", ruoka);//} //the selected food from the menu
                    editor.apply();  //is sent to the feedback activity



                } catch (Exception e) {
                    }
            }
        });

    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String ruoka = parent.getItemAtPosition(position).toString();
        SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
        editor.putString("food",ruoka); //puts the selected food in storage
        editor.apply();


        switch (position) {
            case 0:


                break;

            case 1:

                break;
            case 2:

                break;
            case 3:

                break;

        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


    public void openCalendar() {
        Intent intent = new Intent(this, CalendarActivity.class);

        intent.putExtra ( "info","1");
        startActivity(intent); //takes the user to the calendar portion of the app
    }

    public void openMenu(){
        Intent intentm = new Intent(this, MainActivity.class);
        startActivity(intentm); //takes the user to the main menu portion of the app
    }


}









