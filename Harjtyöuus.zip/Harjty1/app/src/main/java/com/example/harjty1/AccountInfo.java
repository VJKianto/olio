package com.example.harjty1;

import android.widget.EditText;

public class AccountInfo extends Activity4 { //storing the given account values
    Activity4 accinfo=new Activity4();
    public EditText getName(){  //doesn't work with a string even if toString is used
        return accinfo.PName;
    }
    public EditText getEmail(){
        return accinfo.Email;
    }
    public EditText getPnum(){
        return accinfo.PNum;
    }
    public EditText getAddress(){
        return accinfo.Address;
    }



}
